<?php
echo round(microtime(true) * 1000);
?>